package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgentamentoConsultasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgentamentoConsultasApplication.class, args);
	}

}
